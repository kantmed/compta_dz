from odoo import models


class AccountMoveLine(models.Model):
    _inherit = ["account.move.line", "ca.audit.mixin"]
