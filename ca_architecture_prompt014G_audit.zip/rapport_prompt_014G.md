# Rapport — Prompt 014-G : Levée des dernières anomalies documentaires

## 1. Contradictions corrigées

- La relation société-dossier est clarifiée : le dossier est fonctionnellement indépendant, mais obligatoirement rattaché à une seule société cliente par `company_id`.
- La relation redondante entre `CaAccountingFolder` et `ResCompany` a été supprimée du diagramme.
- La relation `partner_id` est présentée comme une association, et non comme un héritage.
- Le mandat est identifié comme un modèle futur non développé.
- La sécurité actuellement implémentée est distinguée de la sécurité cible.
- Les 48 tests, 0 échec et 0 erreur sont correctement mentionnés.
- Le rattachement société-dossier a été retiré des hypothèses à confirmer.

## 2. Décisions conservées

- `res.company` représente la société juridique.
- `res.partner`, `res.users` et `res.groups` sont réutilisés.
- `ca_core` dépend uniquement de `base`.
- `ir.access` gère les restrictions par domaine.
- L'isolation combine la société et le dossier.
- Le dossier est fonctionnellement indépendant, mais rattaché à une seule société cliente.

## 3. Contrôles effectués

- Cohérence des trois documents : vérifiée.
- Relation société-dossier : une seule relation dans le diagramme.
- Absence de l'ancienne hypothèse société-dossier : vérifiée.
- Relation `partner_id` : présentée comme association.
- Mandat : identifié comme futur et non développé.
- Tests : 48 exécutés, 0 échec, 0 erreur.
- Absence de cardinalité définitive pour les exercices : vérifiée.
- Une seule définition `classDiagram` : vérifiée.
- État Git préservé : vérifié.

## 4. Confirmation

Aucun fichier Python, XML, CSV ou manifeste n'a été modifié. Aucun modèle n'a été créé. Aucune table ni donnée PostgreSQL n'a été modifiée. Aucun commit Git n'a été effectué.

## 5. Conclusion

PROMPT 014-G TERMINÉ — DOCUMENTATION EN ATTENTE DE VALIDATION INDÉPENDANTE.
