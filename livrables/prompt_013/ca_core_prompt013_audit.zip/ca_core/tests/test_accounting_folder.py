from psycopg2 import IntegrityError

from odoo import Command
from odoo.exceptions import AccessError, ValidationError
from odoo.tests import TransactionCase, tagged


@tagged("post_install", "-at_install")
class TestCaAccountingFolder(TransactionCase):

    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        cls.company_a = cls.env["res.company"].create({"name": "Company A"})
        cls.company_b = cls.env["res.company"].create({"name": "Company B"})

        cls.group_user = cls.env.ref("ca_core.group_ca_core_user")
        cls.group_manager = cls.env.ref("ca_core.group_ca_core_manager")
        cls.group_admin = cls.env.ref("ca_core.group_ca_core_admin")

        cls.user_a = cls.env["res.users"].create(
            {
                "name": "User A",
                "login": "ca_test_user_a",
                "company_id": cls.company_a.id,
                "company_ids": [Command.set([cls.company_a.id])],
                "group_ids": [Command.set([cls.group_user.id])],
            }
        )
        cls.manager_a = cls.env["res.users"].create(
            {
                "name": "Manager A",
                "login": "ca_test_manager_a",
                "company_id": cls.company_a.id,
                "company_ids": [Command.set([cls.company_a.id])],
                "group_ids": [Command.set([cls.group_manager.id])],
            }
        )
        cls.admin_a = cls.env["res.users"].create(
            {
                "name": "Admin A",
                "login": "ca_test_admin_a",
                "company_id": cls.company_a.id,
                "company_ids": [Command.set([cls.company_a.id])],
                "group_ids": [Command.set([cls.group_admin.id])],
            }
        )
        cls.user_b = cls.env["res.users"].create(
            {
                "name": "User B",
                "login": "ca_test_user_b",
                "company_id": cls.company_b.id,
                "company_ids": [Command.set([cls.company_b.id])],
                "group_ids": [Command.set([cls.group_user.id])],
            }
        )

    def _create_folder(self, company=None, manager=None, code="FOLDER-1", **kwargs):
        company = company or self.company_a
        manager = manager or self.manager_a
        vals = {
            "name": "Test Folder",
            "code": code,
            "company_id": company.id,
            "manager_id": manager.id,
        }
        vals.update(kwargs)
        return self.env["ca.accounting.folder"].create(vals)

    def test_create_valid_folder(self):
        folder = self._create_folder()
        self.assertEqual(folder.state, "draft")
        self.assertEqual(folder.company_id, self.company_a)

    def test_refuse_without_company(self):
        with self.assertRaises(ValidationError):
            self.env["ca.accounting.folder"].create(
                {
                    "name": "No Company",
                    "code": "NO-COMPANY",
                    "company_id": False,
                    "manager_id": self.manager_a.id,
                }
            )

    def test_refuse_without_manager(self):
        with self.assertRaises(ValidationError):
            self.env["ca.accounting.folder"].create(
                {
                    "name": "No Manager",
                    "code": "NO-MANAGER",
                    "company_id": self.company_a.id,
                    "manager_id": False,
                }
            )

    def test_duplicate_code_same_company(self):
        self._create_folder(code="DUPLICATE")
        with self.assertRaises(IntegrityError):
            self._create_folder(code="DUPLICATE")

    def test_same_code_different_company(self):
        self._create_folder(company=self.company_a, code="SAME-CODE")
        folder_b = self._create_folder(company=self.company_b, manager=self.user_b, code="SAME-CODE")
        self.assertEqual(folder_b.company_id, self.company_b)

    def test_manager_company_coherence(self):
        with self.assertRaises(ValidationError):
            self._create_folder(company=self.company_b, manager=self.manager_a)

    def test_collaborator_company_coherence(self):
        with self.assertRaises(ValidationError):
            self._create_folder(collaborator_ids=[Command.set([self.user_b.id])])

    def test_closing_date_before_opening(self):
        with self.assertRaises(ValidationError):
            self._create_folder(
                opening_date="2026-02-01",
                closing_date="2026-01-01",
            )

    def test_status_transitions(self):
        folder = self._create_folder()
        folder.action_activate()
        self.assertEqual(folder.state, "active")
        folder.action_review()
        self.assertEqual(folder.state, "review")
        folder.action_close()
        self.assertEqual(folder.state, "closed")
        folder.action_archive()
        self.assertEqual(folder.state, "archived")
        with self.assertRaises(ValidationError):
            folder.action_activate()

    def test_archived_folder_not_modifiable(self):
        folder = self._create_folder()
        folder.action_activate()
        folder.action_close()
        folder.action_archive()
        with self.assertRaises(ValidationError):
            folder.with_user(self.manager_a).write({"description": "changed"})

    def test_manager_can_create_and_update(self):
        folder = self._create_folder().with_user(self.manager_a)
        folder.write({"description": "updated by manager"})
        self.assertEqual(folder.description, "updated by manager")

    def test_user_read_assigned_folder(self):
        folder = self._create_folder(collaborator_ids=[Command.set([self.user_a.id])])
        read_folder = folder.with_user(self.user_a)
        self.assertEqual(read_folder.name, folder.name)

    def test_user_cannot_read_unassigned_folder(self):
        folder = self._create_folder()
        with self.assertRaises(AccessError):
            folder.with_user(self.user_a).read(["name"])

    def test_user_cannot_create_folder(self):
        with self.assertRaises(AccessError):
            self.env["ca.accounting.folder"].with_user(self.user_a).create(
                {
                    "name": "Forbidden",
                    "code": "FORBIDDEN",
                    "company_id": self.company_a.id,
                    "manager_id": self.manager_a.id,
                }
            )

    def test_user_cannot_update_folder(self):
        folder = self._create_folder(collaborator_ids=[Command.set([self.user_a.id])])
        with self.assertRaises(AccessError):
            folder.with_user(self.user_a).write({"description": "forbidden"})

    def test_user_cannot_change_company(self):
        folder = self._create_folder(collaborator_ids=[Command.set([self.user_a.id])])
        with self.assertRaises((ValidationError, AccessError)):
            folder.with_user(self.manager_a).write({"company_id": self.company_b.id})

    def test_user_cannot_add_self_to_unauthorized_folder(self):
        folder = self._create_folder()
        with self.assertRaises(AccessError):
            folder.with_user(self.user_a).write({"collaborator_ids": [Command.link(self.user_a.id)]})

    def test_manager_cross_company_denied(self):
        folder_b = self._create_folder(company=self.company_b, manager=self.user_b, code="B-FOLDER")
        with self.assertRaises(AccessError):
            folder_b.with_user(self.manager_a).read(["name"])

    def test_manager_rights(self):
        folder = self._create_folder()
        self.assertTrue(folder.with_user(self.manager_a).has_access("write"))

    def test_admin_rights(self):
        folder = self._create_folder()
        self.assertTrue(folder.with_user(self.admin_a).has_access("write"))
